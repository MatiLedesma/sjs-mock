import { mockData } from "./mockData";
export { mockData };

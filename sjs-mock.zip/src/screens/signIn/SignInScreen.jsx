import React from 'react';
import { Text, View } from 'react-native';

export default function SignIn() {
    return (
        <View style={{ justifyContent: 'center', alignItems: 'center', flex: 1 }}>
            <Text>Sign In</Text>
        </View>
    )
}